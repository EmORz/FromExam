﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SIS.MvcFramework.ViewEngine
{
    public interface IViewWidget
    {
        string Render();
    }
}
