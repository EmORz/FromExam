﻿namespace SIS.MvcFramework.Result
{
    using HTTP.Responses;

    public interface IActionResult : IHttpResponse
    {
    }
}
