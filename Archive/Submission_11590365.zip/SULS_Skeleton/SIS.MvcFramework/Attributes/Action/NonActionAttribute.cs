﻿using System;

namespace SIS.MvcFramework.Attributes.Action
{
    public class NonActionAttribute : Attribute
    {
    }
}
