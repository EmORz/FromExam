﻿namespace SULS.Data
{
    public class DbSettings
    {

        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=SULSDB_EmanuilNikolov;Trusted_Connection=True;Integrated Security=True;";
    }
}