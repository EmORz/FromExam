﻿using SIS.MvcFramework;

namespace SULS.App.Controllers
{
    public class SubmissionController : Controller
    {
        
    }
}